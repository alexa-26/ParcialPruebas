package Logica;

public class ManagementCardPhone {
	
	public ManagementCardPhone() {
	
	}
	public boolean addCard(String id, double reidue) {
		return false;
	}
	
	public boolean addCard (String number) {
		return false;
	}

	

}
