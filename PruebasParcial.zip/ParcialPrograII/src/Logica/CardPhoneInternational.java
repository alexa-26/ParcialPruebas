package Logica;

public class CardPhoneInternational extends CardPhone {

	public CardPhoneInternational(String idCard, double residue) {
		super(idCard, residue);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean callingPhone() {
		// TODO Auto-generated method stub
		return false;
	}


	

	
	
	
	

}
