package Logica;

public class CardPhoneNational extends CardPhone{

	public CardPhoneNational(String idCard, double residue) {
		super(idCard, residue);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean callingPhone() {
		// TODO Auto-generated method stub
		return false;
	}



}
